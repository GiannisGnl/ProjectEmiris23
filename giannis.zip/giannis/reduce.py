import argparse

# Parse command line arguments
parser = argparse.ArgumentParser(description='Train an image autoencoder.')
parser.add_argument('-d', '--dataset', type=str, required=True,
                    help='Path to the input dataset directory with images.')
parser.add_argument('-q', '--queryset', type=str, required=True,
                    help='Path to the input query set directory with images.')
parser.add_argument('-od', '--output_dataset_file', type=str, required=True,
                    help='Path to the output reduced dataset file.')
parser.add_argument('-oq', '--output_query_file', type=str, required=True,
                    help='Path to the output reduced query file.')
args = parser.parse_args()




# Load the entire model
loaded_autoencoder = load_model('autoencoder_model.h5')

# Extract the encoder part (assuming encoder is the second-to-last layer)
loaded_encoder = models.Model(inputs=loaded_autoencoder.input, outputs=loaded_autoencoder.layers[-2].output)

# Use the loaded encoder for predictions
compressed_dataset = loaded_encoder.predict(input_images)



# Function to save the compressed images
def save_compressed_images(images, encoder, file_path):
    compressed = encoder.predict(images)
    np.save(file_path, compressed)

# Saving output compressed files
save_compressed_images(input_images, encoder, args.output_dataset_file)
save_compressed_images(input_images, encoder, args.output_query_file)