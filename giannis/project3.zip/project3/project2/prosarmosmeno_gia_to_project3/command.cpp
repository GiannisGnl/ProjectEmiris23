#include "command.h"
#include "parse.h"

using namespace std;


Command::Command(vector<string> inp){
	
	int i;
	
	if (inp[0] != "graph_search" && inp[0] != "./graph_search")
		this->valid = 0;
	
	else{
	
		string value;
		this->valid = 1;
		
		value = parameterValue(inp, "-m");
		if (value == "1")
			this->valid = 1;
			
		else if (value == "2")
			this->valid = 2;
			
		else
			this->valid = 0;
		
		value = parameterValue(inp, "-d");
		if (value == "") 
			this->valid = 0;
		
		else
			this->inputFile = this->fixPath(value);
			
		value = parameterValue(inp, "-sd");
		if (value == "") 
			this->valid = 0;
		
		else
			this->startingSpaceInputFile = this->fixPath(value);
		
			
		value = parameterValue(inp, "-o");
		if (value == "") 
			this->valid = 0;
			
		else
			this->outputFile = this->fixPath(value);
		
			
		value = parameterValue(inp, "-q");
		if (value == "") 
			this->valid = 0;
			
		else
			this->queryFile = this->fixPath(value);
			
			
		value = parameterValue(inp, "-sq");
		if (value == "") 
			this->valid = 0;
			
		else
			this->startingSpaceQueryFile = this->fixPath(value);
			
		
		if (this->valid){
			
			this->k = 50;
			this-> e = 30;
			this->r = 1;
			this->n = 1;
			this->l = 20;
			
			value = parameterValue(inp, "-k");
			if (value != "")
				this->k = stoi(value);
				
			value = parameterValue(inp, "-E");
			if (value != "")
				this->e = stoi(value);
				
			value = parameterValue(inp, "-R");
			if (value != "")
				this->r = stoi(value);
				
			value = parameterValue(inp, "-N");
			if (value != "")
				this->n = stoi(value);
				
			value = parameterValue(inp, "-l");
			if (value != "")
				this->l = stoi(value);
				
			if (this->e > this->k)
				this->e = this->k;
				
			if (this->l < this->n)
				this->l = this->n;	
			
	
		}
	
	}
	
}


int Command::getValid(){
	
	return this->valid;

}
	
	
string Command::getInputFile(){

	return this->inputFile;

}
	
	
string Command::getOutputFile(){

	return this->outputFile;

}
	
	
string Command::getQueryFile(){

	return this->queryFile;

}


string Command::getStartingSpaceInputFile(){

	return this->startingSpaceInputFile;

}


string Command::getStartingSpaceQueryFile(){

	return this->startingSpaceQueryFile;

}
	
	
int Command::getK(){

	return this->k;

}
	
	
int Command::getE(){

	return this->e;

}
	
	
int Command::getR(){

	return this->r;

}


int Command::getN(){

	return this->n;

}

	
int Command::getL(){

	return this->l;

}


string Command::fixPath(string input){
	
	if (input[0] == '/')
	    input.erase(0, 1);
	
	int i = 0;

    while (i < input.length()){
	   
	   
	    if (input[i] == '/' && input[i+1] != '/'){
			input.insert(i, "/");
		
			i += 2;
		
		
		}
		
		i++;
	   
    }
    
    return input;
	
}
