#ifndef GRAPHNODE_H
#define GRAPHNODE_H

#include "pointvector.h"


using namespace std;


class GraphNode{
	
	private:
	
		PointVector* node;
		vector<GraphNode*> neighbours;
		
	public:
	
		GraphNode(PointVector*);
		void setNeighbours(vector<GraphNode*>);
		void setMRNG(vector<GraphNode*>);
		vector<GraphNode*> getNeighbours();
		GraphNode* getNeighbour(int);
		PointVector* getNode();
		~GraphNode();
		
	
};

vector<unsigned int> searchGNNS(vector <GraphNode*>, PointVector*, int, int, int);
vector<unsigned int> searchMRNG(GraphNode*, PointVector*, int, int);
vector<unsigned int> searchTrue(vector <GraphNode*>, PointVector*, int);
void writeToFileGNNS(string, vector<GraphNode*>, vector<PointVector*>, int, int, int, int);
void writeToFileGNNS(string, vector<GraphNode*>, vector<PointVector*>, vector<PointVector*>, vector<PointVector*>, int, int, int, int);
void writeToFileMRNG(string, vector<GraphNode*>, GraphNode*, vector<PointVector*>, int, int);
void writeToFileMRNG(string, vector<GraphNode*>, GraphNode*, vector<PointVector*>, vector<PointVector*>, vector<PointVector*>, int, int);
GraphNode* navigate(vector<GraphNode*>);


#endif
