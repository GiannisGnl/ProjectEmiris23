#include <string>
#include <vector>

using namespace std;


class Command{
	
	private:
		
		int valid;
		string inputFile;
		string outputFile;
		string queryFile;
		string startingSpaceInputFile;
		string startingSpaceQueryFile;
		int k;
		int e;
		int r;
		int n;
		int l;
		
		
	public:
		
		Command(vector<string>);
		int getValid();
		string getInputFile();
		string getOutputFile();
		string getQueryFile();
		string getStartingSpaceInputFile();
		string getStartingSpaceQueryFile();
		int getK();
		int getE();
		int getR();
		int getN();
		int getL();
		string fixPath(string);
	
};
