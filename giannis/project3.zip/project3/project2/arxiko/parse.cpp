#include <fstream>
#include <cctype>
#include "parse.h"
#include <iostream>


using namespace std;

vector<PointVector*> parse(string fileName, unsigned int* imagesCounter, int dimensions, bool flag, unsigned int limit){
	
	char c;
	unsigned char uc;
    PointVector *pV;
    vector<unsigned char> coor;
    vector<PointVector*> result;
    
    unsigned int counter = 0;
    
    ifstream file;
    file.open(fileName, ifstream::binary);
	file.ignore(16);
	
	
	while (file.get(c) && counter < limit){
				
		counter++;
		
		coor.push_back((unsigned char) c);
				
		for (int i = 1; i < dimensions; i++){
					
			file.get(c);
			coor.push_back((unsigned char) c);
					
		}
				
		pV = new PointVector(counter, coor);
		result.push_back(pV);
		coor.clear();
		coor.shrink_to_fit();
				
	}
	
	
	file.close();
	
	if (flag)
		*imagesCounter = counter;
	
	return result;
	
}


string parameterValue(vector<string> vec, string parameter){
	
	for (int i = 0; i < vec.size(); i++){
		
		if (vec[i] == parameter)
			return vec[i+1];
		
	}
	
	return "";
	
}


bool found(vector<string> vec, string input){
	
	for (int i = 0; i < vec.size(); i++){
		
		if (vec[i] == input)
			return true;
		
	}
	
	return false;
	
}


vector<string> parseCommand(string input){
	
	vector<string> par;
	int i = 0, j = 0;
	bool notEnd = true;
	
		
	while (i < input.length()){
		
		par.push_back("");
		
		while (!isspace(input[i])){
			
			par[j] += input[i];
			i++;
			
			if (i == input.length())
			 break;
		
		}
			
		j++;
		i++;

	}
	
	return par;
	
}


/*vector<int> parseConfigurationFile(string fileName){
	
	vector<int> parameters;
	
	ifstream file;
	string curLine;
	vector <string> fileStrings, temp;
	int kClusters, lLSH = 3, kLSH = 4, mHC = 10, kHC = 3, pHC = 2;
	
	file.open(fileName);
	
	while (getline(file, curLine)) {

		temp = parseCommand(curLine);
		
		fileStrings.push_back(temp[0]);
		fileStrings.push_back(temp[1]);
		
		cout << "string1: " << temp[0] << endl;
		cout << "string2: " << temp[1] << endl;
		
		temp.clear();
		
		
    }
    
    file.close();
    
    string parValue;
    
    
    parValue = parameterValue(fileStrings, "number_of_clusters:");
    
    if (parValue == "")
		return parameters;
	
	kClusters = stoi(parValue);
	parameters.push_back(kClusters);
	
	cout << "kClusters: " << kClusters << endl;
	
	
	parValue = parameterValue(fileStrings, "number_of_vector_hash_tables:");
	
	if (parValue != "")
		lLSH = stoi(parValue);
	
	parameters.push_back(lLSH);
	
	cout << "lLSH: " << lLSH << endl;
	
		
	parValue = parameterValue(fileStrings, "number_of_vector_hash_functions:");
	
	if (parValue != "")
		kLSH = stoi(parValue);
		
	parameters.push_back(kLSH);
	
	cout << "kLSH: " << kLSH << endl;
		
	
	parValue = parameterValue(fileStrings, "max_number_M_hypercube:");
	
	if (parValue != "")
		mHC = stoi(parValue);
		
	parameters.push_back(mHC);
	
	cout << "mHC: " << mHC << endl;
		
	
	parValue = parameterValue(fileStrings, "number_of_hypercube_dimensions:");
	
	if (parValue != "")
		kHC = stoi(parValue);
		
	parameters.push_back(kHC);
	
	cout << "kHC: " << kHC << endl;
		
	
	parValue = parameterValue(fileStrings, "number_of_probes:");
	
	if (parValue != "")
		pHC = stoi(parValue);
		
	parameters.push_back(pHC);
	
	cout << "pHC: " << pHC << endl;
	
	for(int i = 0; i < parameters.size(); i++){
		
		cout << "param" << i+1 << ": " << parameters[i] << endl;
		
	}
	
	
	return parameters;
	
}*/
