#include "pointvector.h"

PointVector::PointVector(unsigned int imageNumber, vector<unsigned char> coor){
    
    this->id = imageNumber;
    
    for (int i = 0; i < coor.size(); i++)
        this->co.push_back(coor[i]);
    
}

int PointVector::getDimension(){

    return this->co.size();

}


unsigned int PointVector::getID() {

    return this->id;

}


vector<unsigned char> PointVector::getCoordinates() {

    return this->co;

}


unsigned char PointVector::getCoordinate(int pos) {

    return this->co[pos];

}


PointVector::~PointVector(){
	
	this->co.clear();
	this->co.shrink_to_fit();
	
}
