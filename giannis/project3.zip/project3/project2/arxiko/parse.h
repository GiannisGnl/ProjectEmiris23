#ifndef PARSE_H
#define PARSE_H

#include <string>
#include <vector>
#include <climits>
#include "pointvector.h"

using namespace std;

vector<PointVector*> parse(string, unsigned int*, int, bool = true, unsigned int = UINT_MAX);
string parameterValue(vector<string>, string);
bool found(vector<string>, string);
vector<string> parseCommand(string);
//vector<int> parseConfigurationFile(string);

#endif
