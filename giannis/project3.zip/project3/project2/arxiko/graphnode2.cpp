#include <random>
#include <cmath>
#include <algorithm>
#include <cfloat>
#include <string>
#include <chrono>
#include <fstream>
#include "graphnode.h"
#include "metricl2.h"
#include <iostream>


using namespace std;
using namespace std::chrono;


GraphNode::GraphNode(PointVector* point){
	
	this->node = point;
	
}



void GraphNode::setNeighbours(vector<GraphNode*> ne){
	
	this->neighbours = ne;
	
}


vector<GraphNode*> GraphNode::getNeighbours(){
	
	return this->neighbours;
	
}


GraphNode* GraphNode::getNeighbour(int i){
	
	return this->neighbours[i];
	
}


PointVector* GraphNode::getNode(){
	
	return this->node;
	
}


vector<unsigned int> searchGNNS(vector<GraphNode*> restartNodes, PointVector* query, int k, int e, int n){

	vector<double> distances;
	vector<unsigned int> nID; 
	GraphNode* currentNode;

	double curDis, curNav, curMin, tempDis;
	unsigned int tempID;
	int posMin, i, m, neighboursAdded, j;
	
	bool terminationCondition;

	for (i = 0; i < restartNodes.size(); i++){
		
		currentNode = restartNodes[i];

		curNav = distanceL2(currentNode->getNode(), query);
		
		if (i == 0){

			distances.push_back(curNav);
			nID.push_back(currentNode->getNode()->getID());
		
		}
		
		else{
		
			if (find(nID.begin(), nID.end(), currentNode->getNode()->getID()) == nID.end()){
				
				distances.push_back(curNav);
				nID.push_back(currentNode->getNode()->getID());
				
				m = nID.size() - 1;
				
				while (m > 0 && distances[m] < distances[m-1]){
					
					tempDis = distances[m-1];
					distances[m-1] = distances[m];
					distances[m] = tempDis;
					
					tempID = nID[m-1];
					nID[m-1] = nID[m];
					nID[m] = tempID;
					
					m--;
					
				}
				
			}
		
		}
		
		terminationCondition = true;
		
		
		do{
			
			curMin = DBL_MAX;
			neighboursAdded = 0;
			j = 0;
		
			while(neighboursAdded < e && j < currentNode->getNeighbours().size()){
	
				if (find(nID.begin(), nID.end(), currentNode->getNeighbour(j)->getNode()->getID()) != nID.end()){
					
					j++;
					continue;
					
				}
				
				
				//currentNeighbours.push_back(currentNode->getNeighbour(j));
				nID.push_back(currentNode->getNeighbour(j)->getNode()->getID());
				curDis = distanceL2(currentNode->getNeighbour(j)->getNode(), query);
				distances.push_back(curDis);
				
				if (curDis < curMin){
					
					posMin = j;
					curMin = curDis;
					
				}
					
				m = nID.size() - 1;
				
				while (m > 0 && distances[m] < distances[m-1]){
					
					tempDis = distances[m-1];
					distances[m-1] = distances[m];
					distances[m] = tempDis;
					
					tempID = nID[m-1];
					nID[m-1] = nID[m];
					nID[m] = tempID;
					
					m--;
					
				}
				
				j++;
				neighboursAdded++;
			
			}
			
			if (curMin < curNav){
				
				curNav = curMin;
				currentNode = currentNode->getNeighbour(posMin);
			
			}
			
			else
				terminationCondition = false;
			
		} while(terminationCondition || nID.size() < k);
		
		
	}
	
	while (nID.size() > n)
		nID.pop_back();
		
	nID.shrink_to_fit();
	distances.clear();
	distances.shrink_to_fit();
	
	
	return nID;

}


vector<unsigned int> searchTrue(vector<GraphNode*> points, PointVector* query, int n){
	
	vector <double> distances;
    distances.resize(n);

    int i, j, pos;
    double currentDis, tempD;
    unsigned int tempS;
    
    for (i = 0; i < n; i++)
		distances[i] = DBL_MAX;

	vector<unsigned int> nID;
    nID.resize(n);
    
    for (i = 0; i < points.size(); i++) {

		pos = n;

        currentDis = distanceL2(query, points[i]->getNode());
        
        while (currentDis < distances[pos - 1]) {

			pos--;

            if (pos == n - 1) {

				distances[pos] = currentDis;
				nID[pos] = points[i]->getNode()->getID();

            }

            else {

                tempD = distances[pos];
                distances[pos + 1] = tempD;
                distances[pos] = currentDis;
                tempS = nID[pos];
                nID[pos + 1] = tempS;
                nID[pos] = points[i]->getNode()->getID();

            }
            
            if (pos == 0)
				break;

        }


    }
    
    
    return nID;
	
}


void writeToFileGNNS(string fileName, vector<GraphNode*> pointSet, vector<PointVector*> queries, int k, int e, int r, int n){
	
	vector<unsigned int> nID, nIDt;
	int i, j, m;
	string output = "GNNS Results";
	output += "\n";
	double durApp = 0.0, durTrue = 0.0, maf = 0, af;
	
	vector<int> restartIndexes;
    vector<GraphNode*> restartNodes;
	
	for (i = 0; i < queries.size(); i++){

		
		//upologismos xronou arxi
		auto start = high_resolution_clock::now();
		
		for (m = 0; m < r; m++){
						
			random_device rd;
			mt19937 gen(rd());
			uniform_int_distribution<> distributionR(0, pointSet.size()-1);
			j = distributionR(gen);

			while (find(restartIndexes.begin(), restartIndexes.end(), j) != restartIndexes.end())
				j = distributionR(gen);
							
			restartIndexes.push_back(j);
			restartNodes.push_back(pointSet[j]);
						
		}
		
		nID = searchGNNS(restartNodes, queries[i], k, e, n);
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<microseconds>(stop - start);
		durApp += (double)duration.count();
		
		restartIndexes.clear();
		restartIndexes.shrink_to_fit();
		restartNodes.clear();
		restartNodes.shrink_to_fit();

		
		start = high_resolution_clock::now();
		nIDt = searchTrue(pointSet, queries[i], n);
		stop = high_resolution_clock::now();
		duration = duration_cast<microseconds>(stop - start);
		durTrue += (double)duration.count();

		
		output += "Query: ";
		output += to_string(i+1);
		output += "\n";
		
		for (j = 0; j < n; j++){
			
			output += "Nearest neighbor-";
			output += to_string(j+1);
			output += ": ";
			output += to_string(nID[j]);
			output += "\n";
			
			output += "distanceApproximate: ";
			output += to_string(distanceL2(queries[i], pointSet[nID[j]-1]->getNode()));
			output += "\n";
			
			
			output += "distanceTrue: ";
			output += to_string(distanceL2(queries[i], pointSet[nIDt[j]-1]->getNode()));
			output += "\n";
			
			
		}
		
		output += "\n";
		
		af = distanceL2(queries[i], pointSet[nID[0]-1]->getNode()) / distanceL2(queries[i], pointSet[nIDt[0]-1]->getNode());
		
		if (af > maf)
			maf = af;
			
		nID.clear();
		nID.shrink_to_fit();
		nIDt.clear();
		nIDt.shrink_to_fit();
		
	}
	
	output += "tAverageApproximate: ";
	output += to_string(durApp / (double) queries.size());
	output += "\n";
	
	output += "tAverageTrue: ";
	output += to_string(durTrue / (double) queries.size());
	output += "\n";
	
	output += "MAF: ";
	output += to_string(maf);
	output += "\n";
	
	
	ofstream write(fileName);	
		
	write << output;
	
	write.close();
	
}



GraphNode::~GraphNode(){
	
	delete this->node;
	this->node = NULL;
	this->neighbours.clear();
	this->neighbours.shrink_to_fit();
	
}


void GraphNode::setMRNG(vector<GraphNode*> pointSet){
	
	vector <GraphNode*> lP;
	double curDis, minDis = DBL_MAX, pr, pt, rt;
	
	for (int i = 0; i < pointSet.size(); i++){
		
		if (this->node->getID() == pointSet[i]->getNode()->getID())
			continue;
		
		curDis = distanceL2(this->node, pointSet[i]->getNode());
		
		if (curDis == minDis)
			lP.push_back(pointSet[i]);
		
		if (curDis < minDis){
			
			lP.clear();
			lP.push_back(pointSet[i]);
			minDis = curDis;
			
		}
		
	}
	
	//cout << "step1 - lpsize: " << lP.size() << endl;
	//for (int kl = 0; kl < lP.size(); kl++)
	//	cout << "lP[" << kl << "] = " << lP[kl]->getNode()->getID() << endl;
	
	
	
	for (int i = 0; i < pointSet.size(); i++){
		
		bool condition = true;
		
		if (this->node->getID() == pointSet[i]->getNode()->getID() || find(lP.begin(), lP.end(), pointSet[i]) != lP.end())
			continue;
			
		for (int j = 0; j < lP.size(); j++){
			
			pr = distanceL2(pointSet[i]->getNode(), this->getNode());
			pt = distanceL2(pointSet[i]->getNode(), lP[j]->getNode());
			rt = distanceL2(lP[j]->getNode(), this->getNode());
			
			if (pr > pt && pr > rt){
				
				condition = false;
				break;
				
			}
			
		}
		
		if (condition)
			lP.push_back(pointSet[i]);
		
	}
	
	//cout << "step2 - lpsize: " << lP.size() << endl;
	//for (int kl = 0; kl < lP.size(); kl++)
	//	cout << "lP[" << kl << "] = " << lP[kl]->getNode()->getID() << endl;
		
	//cout << endl;
	
	
	this->neighbours = lP;
	
}


GraphNode* navigate(vector<GraphNode*> pointSet){
	
	PointVector* centroid;
	vector<unsigned int> navigationID;
	GraphNode* navigation;
	
	unsigned long long int	coordinate;
	vector<unsigned char> coordinates;
	
	for (int i = 0; i < pointSet[0]->getNode()->getDimension(); i++){
		
		coordinate = 0;
	
		for (int j = 0; j < pointSet.size(); j++)
			coordinate += (unsigned long long int) pointSet[j]->getNode()->getCoordinate(i);
			
		coordinate /= (unsigned long long int) pointSet.size();
		coordinates.push_back((unsigned char) coordinate);

		
	}
	
	centroid = new PointVector(0, coordinates);
	
	navigationID = searchTrue(pointSet, centroid, 1);
	navigation = pointSet[navigationID[0]-1];
	
	delete centroid;
	navigationID.clear();
	navigationID.shrink_to_fit();
	
	
	return navigation;
	
}


void writeToFileMRNG(string fileName, vector<GraphNode*> pointSet, GraphNode* navigation, vector<PointVector*> queries, int l, int n){
	
	vector<unsigned int> nID, nIDt;
	int i, j, m;
	string output = "MRNG Results";
	output += "\n";
	double durApp = 0.0, durTrue = 0.0, maf = 0, af;
	

	
	for (i = 0; i < queries.size(); i++){

		
		//upologismos xronou arxi
		auto start = high_resolution_clock::now();
		
		nID = searchMRNG(navigation, queries[i], n, l);
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<microseconds>(stop - start);
		durApp += (double)duration.count();

		
		start = high_resolution_clock::now();
		nIDt = searchTrue(pointSet, queries[i], n);
		stop = high_resolution_clock::now();
		duration = duration_cast<microseconds>(stop - start);
		durTrue += (double)duration.count();

		
		output += "Query: ";
		output += to_string(i+1);
		output += "\n";
		
		for (j = 0; j < n; j++){
			
			output += "Nearest neighbor-";
			output += to_string(j+1);
			output += ": ";
			output += to_string(nID[j]);
			output += "\n";
			
			output += "distanceApproximate: ";
			output += to_string(distanceL2(queries[i], pointSet[nID[j]-1]->getNode()));
			output += "\n";
			
			
			output += "distanceTrue: ";
			output += to_string(distanceL2(queries[i], pointSet[nIDt[j]-1]->getNode()));
			output += "\n";
			
			
		}
		
		output += "\n";
		
		af = distanceL2(queries[i], pointSet[nID[0]-1]->getNode()) / distanceL2(queries[i], pointSet[nIDt[0]-1]->getNode());
		
		if (af > maf)
			maf = af;
			
		nID.clear();
		nID.shrink_to_fit();
		nIDt.clear();
		nIDt.shrink_to_fit();
		
	}
	
	output += "tAverageApproximate: ";
	output += to_string(durApp / (double) queries.size());
	output += "\n";
	
	output += "tAverageTrue: ";
	output += to_string(durTrue / (double) queries.size());
	output += "\n";
	
	output += "MAF: ";
	output += to_string(maf);
	output += "\n";
	
	
	ofstream write(fileName);	
		
	write << output;
	
	write.close();
	
	
}



vector<unsigned int> searchMRNG(GraphNode* navigation, PointVector* query, int n, int l){

	vector<double> distances;
	vector<unsigned int> nID; 
	GraphNode* currentNode = navigation;
	GraphNode* nextNode;

	double curDis, curNav, curMin, tempDis;
	unsigned int tempID;
	int posMin, i = 1, m, j, curPos;
	
	curDis = distanceL2(currentNode->getNode(), query);
	distances.push_back(curDis);
	nID.push_back(currentNode->getNode()->getID());
	
	while (i < l){
		
		curPos = 0;
		
		do {
			
			nextNode = currentNode->getNeighbour(curPos);
			curPos++;
			
		} while(find(nID.begin(), nID.end(), nextNode->getNode()->getID()) != nID.end());
		
		for (j = 0; j < currentNode->getNeighbours().size(); j++){
			
			
			if (find(nID.begin(), nID.end(), currentNode->getNeighbour(j)->getNode()->getID()) == nID.end()){
				
				curDis = distanceL2(currentNode->getNeighbour(j)->getNode(), query);
				distances.push_back(curDis);
				nID.push_back(currentNode->getNeighbour(j)->getNode()->getID());
				
				i++;
				
				m = nID.size() - 1;
				
				while (m > 0 && distances[m] < distances[m-1]){
					
					tempDis = distances[m-1];
					distances[m-1] = distances[m];
					distances[m] = tempDis;
					
					tempID = nID[m-1];
					nID[m-1] = nID[m];
					nID[m] = tempID;
					
					m--;
					
				}
			
			}
			
		}
		
		currentNode = nextNode;
		
	}
	
	while (nID.size() > n)
		nID.pop_back();
		
	nID.shrink_to_fit();
	distances.clear();
	distances.shrink_to_fit();
	
	
	return nID;

}
