#ifndef METRICL2_H
#define METRICL2_H

#include "pointvector.h"


double distanceL2(PointVector*, PointVector*);
int binarySearchPosition(vector<double>, double);


#endif

