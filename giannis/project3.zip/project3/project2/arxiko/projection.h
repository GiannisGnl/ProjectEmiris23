#ifndef PROJECTION_H
#define PROJECTION_H

#include <vector>
#include "pointvector.h"


using namespace std;


class Projection{

private:

    int k;
    int w;
    vector<vector<double>> v;
    vector<double> t;


public:

  void setH(int);
  void setK(int);
  void setW(int);
  void setVT(int, int);
  int getK();
  int hashLSH(PointVector*, int);
  ~Projection();

};


#endif
