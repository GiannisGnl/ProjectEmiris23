#include "metricl2.h"
#include <cmath>



double distanceL2(PointVector* p1, PointVector* p2){

    double sum = 0.0;

    for (int i = 0; i < p1->getDimension(); i++)
        sum += pow((double)p1->getCoordinate(i) - (double)p2->getCoordinate(i), 2.0);

    return sqrt(sum);

}


int binarySearchPosition(vector<double> p, double randomP){
	
	int curPos = p.size()/2;
	int size = curPos;
	int mod;
	
	int i = 0;
	
	while (randomP > p[curPos] || randomP < p[curPos-1]){
		
		mod = size % 2;
		size /= 2;
		size += mod;
		
		if (randomP < p[curPos])
			curPos -= size;
			
		else
			curPos += size;
			
		i++;
		
		if(i > 50)
		break;
		
	}
	
	if (p[curPos-1] == randomP)
		return curPos-1;
		
	return curPos;
	
}
