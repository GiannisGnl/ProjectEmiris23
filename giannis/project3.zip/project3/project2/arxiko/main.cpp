#include <iostream>
#include <vector>
#include <string>
#include <chrono>
#include <cmath>
#include <fstream>
#include <random>
#include <algorithm>
#include "parse.h"
#include "pointvector.h"
#include "lsh.h"
#include "metricl2.h"
//#include "hypercube.h"
#include "command.h"
#include "graphnode.h"


using namespace std;
using namespace std::chrono;


int main(int argc, char** argv){
	
	const int dim = 784;
	const int queriesQuantity = 10;
	const int window = 5;
	const int lLSH = 5;
	const int kLSH = 4;

    vector<PointVector*> toInsert, queries, currentNeighbours;
    unsigned int imagesCounter;
    
    GraphNode* currentNode;
    GraphNode* navigationNode;
    vector<GraphNode*> graphNodes;
    
    vector<int> restartIndexes;
    vector<GraphNode*> restartNodes, neighbs;
    
	vector<string> commandStrings;
	string st = "";
	int i, j;
	
	for (i = 0; i < argc; i++){
		
		st += (string(argv[i]));
		st += " ";
	
	}
    
    Command* com;

    do{
		
		commandStrings = parseCommand(st);

		com = new Command(commandStrings);
		
		commandStrings.clear();
		commandStrings.shrink_to_fit();
		

        if (com->getValid()){
			
				cout << endl;

				cout << "Reading input..." << endl;
	
				toInsert = parse(com->getInputFile(), &imagesCounter, dim);
	
				cout << "Reading input finished!" << endl << endl;
				
				cout << "Reading queries..." << endl;
	
				queries = parse(com->getQueryFile(), &imagesCounter, dim, false, queriesQuantity);
	
				cout << "Reading queries finished!" << endl << endl;
				
				cout << "Creating the nodes of the graph..." << endl;
				
				for (i = 0; i < toInsert.size(); i++){
					currentNode = new GraphNode(toInsert[i]);
					graphNodes.push_back(currentNode);
				}
				
				cout << "Creating nodes finished!" << endl << endl;
				

				if (com->getValid() == 1){
					
					cout << "Creating LSH object..." << endl;
					LSH *lshObj = new LSH(lLSH, kLSH, window, dim, imagesCounter);
					cout << "LSH object created!" << endl << endl;
				
					cout << "Inserting Points into LSH structure..." << endl;
					lshObj->insert(toInsert);
					cout << "Points inserted into LSH structure!" << endl << endl;
					
					cout << "Creating the edges of the graph..." << endl;
					
					for (i = 0; i < toInsert.size(); i++){

						currentNeighbours = lshObj->closestNeighbours(com->getK(), toInsert[i]);
												
						for (j = 0; j < currentNeighbours.size(); j++)
							neighbs.push_back(graphNodes[currentNeighbours[j]->getID()-1]);
							
						
						graphNodes[i]->setNeighbours(neighbs);
						
						
						neighbs.clear();
						neighbs.shrink_to_fit();
						
					}
					
					cout << "Creating edges finished!" << endl << endl;
					
					cout << "Finding the results and writing them to the output file..." << endl;
					
					writeToFileGNNS(com->getOutputFile(), graphNodes, queries, com->getK(), com->getE(), com->getR(), com->getN());
					
					cout << "Results finished!" << endl << endl;
					
					toInsert.clear();
					toInsert.shrink_to_fit();
					

				}

				else{

					cout << "Creating the edges of the graph..." << endl;
					
					for (i = 0; i < toInsert.size(); i++)
						graphNodes[i]->setMRNG(graphNodes);
						
					
					cout << "Creating edges finished!" << endl << endl;
					
					cout << "Finding the results and writing them to the output file..." << endl;
					
					navigationNode = navigate(graphNodes);
					
					writeToFileMRNG(com->getOutputFile(), graphNodes, navigationNode, queries, com->getL(), com->getN());
					
					cout << "Results finished!" << endl << endl;
					
					toInsert.clear();
					toInsert.shrink_to_fit();

				}
				
				for (i = 0; i < graphNodes.size(); i++)
					delete graphNodes[i];
					
				graphNodes.clear();
				graphNodes.shrink_to_fit();

        }

        else{
			
			if (st != "exit"){
				
				cout << "False command, please try again." << endl;
				cout << "The possible commands are the following: " << endl;
				cout << "Command 1" << endl;
				cout << "graph_search -d <input file> -q <query file> -k <int> -E <int> -R <int> -N <int> -l <int, only on Search-on-Graph> -m <1 for GNNS, 2 for MRNG> -o <output file>" << endl;
				cout << "Obligatory parameters: input file, output file, query file and m (method, 1 for GNNS, or 2 for MRNG" << endl;
				cout << "Default values for optional parameters: k = 50,  E = 30,  R = 1,  N = 1, l = 20" << endl << endl;
				cout << "Command 2 (if you want to terminate the program)" << endl;
				cout << "exit" << endl << endl;
				
			}

        }
		
		if (st == "exit"){
			
			cout << "Exiting the programm..." << endl << endl;
			break;
			
		}

		if (com->getValid())
			cout << "Command was executed succesfully!" << endl << endl;
			
		delete com;
		com = NULL;
		
		cout << "Please enter a command: " << endl;
		
		do{
			getline(cin, st);
			cout << endl;
		} while (st == "");

    } while(1);

	
    return 0;
    
}
