#ifndef POINTVECTOR_H
#define POINTVECTOR_H

#include <string>
#include <vector>

using namespace std;


class PointVector{
  
  private:
  
    unsigned int id;
    vector<unsigned char> co;
  
  public:
    
    PointVector(unsigned int, vector<unsigned char>);
    int getDimension();
    unsigned int getID();
    vector<unsigned char> getCoordinates();
    unsigned char getCoordinate(int pos);
    ~PointVector();
    
};


#endif
