#ifndef LSH_H
#define LSH_H


#include <iostream>
#include <string>
#include <stdlib.h>
#include <cmath>
#include "parse.h"
#include "projection.h"


using namespace std;


class LSH : public Projection {

private:

    vector<int> r;
    vector<vector<int>> hashFunc;
    vector<vector<vector<PointVector*>>> hashtables;
    int l;

public:
    LSH(int, int, int, int, int);
    int hashPosition(PointVector*, int);
    void insert(PointVector*);
    void insert(vector<PointVector*>);
    int bucketSize();
    vector<unsigned int> closestNeighbours(int, PointVector*);
    vector<unsigned int> trueClosestNeighbours(int, vector<PointVector*>, PointVector*);
    void writeToFile(string, vector<PointVector*>, vector<PointVector*>, int, double);
    vector<PointVector*> rangeNeighbours(PointVector*, double);
    ~LSH();
    

};


#endif
