#ifndef HYPERCUBE_H
#define HYPERCUBE_H


#include <iostream>
#include <string>
#include <stdlib.h>
#include <cmath>
#include "parse.h"
#include "projection.h"
#include "pointvector.h"


using namespace std;


class Hypercube : public Projection {

private:

    vector<vector<PointVector*>> hashtables;
    int probes;
    int* f;
    int m;
    int vertices;
    int hammingDistance(int, int);

public:
    Hypercube(int, int, int, int, int, int);
    int hashPosition(PointVector*);
    void insert(PointVector*);
    void insert(vector<PointVector*>);
    vector<unsigned int> closestNeighbours(int, PointVector*);
    vector<unsigned int> trueClosestNeighbours(int, vector<PointVector*>, PointVector*);
    void writeToFile(string, vector<PointVector*>, vector<PointVector*>, int, double);
    vector<PointVector*> rangeNeighbours(PointVector*, double);
    ~Hypercube();

};


#endif
