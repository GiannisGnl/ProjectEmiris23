#include <string>
#include <vector>

using namespace std;


class Command{
	
	private:
		
		int valid;
		string inputFile;
		string outputFile;
		string configurationFile;
		int k;
		int lOrM;
		int probes;
		int n;
		double radius;
		string method;
		bool complete;
		
		
	public:
		
		Command(vector<string>);
		int getValid();
		string getInputFile();
		string getOutputFile();
		string getConfigurationFile();
		int getK();
		int getLOrM();
		int getProbes();
		int getN();
		double getRadius();
		string getMethod();
		bool getComplete();
		string fixPath(string);
	
};
