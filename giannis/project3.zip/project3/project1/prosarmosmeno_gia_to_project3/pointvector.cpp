#include "pointvector.h"

PointVector::PointVector(unsigned int imageNumber, vector<unsigned char> coor){
    
    this->id = imageNumber;
    this->flag = false;
    
    for (int i = 0; i < coor.size(); i++)
        this->co.push_back(coor[i]);
    
}

int PointVector::getDimension(){

    return this->co.size();

}


unsigned int PointVector::getID() {

    return this->id;

}


vector<unsigned char> PointVector::getCoordinates() {

    return this->co;

}


unsigned char PointVector::getCoordinate(int pos) {

    return this->co[pos];

}


bool PointVector::getFlag(){

	return this->flag;

}


void PointVector::setFlagTrue(){
	
	this->flag = true;
	
}


PointVector::~PointVector(){
	
	this->co.clear();
	
}
