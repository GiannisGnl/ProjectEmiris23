#include "projection.h"
#include <random>


using namespace std;


void Projection::setK (int kParam){
	
	this->k = kParam;
	
}


void Projection::setW(int window){
	
	this->w = window;
	
}


int Projection::getK(){
	
	return this->k;
	
}


void Projection::setVT(int size, int dim){
	
	int i, j;
	
	this->v.resize(size);
    this->t.resize(size);

    for (i = 0; i < size; i++)
        this->v[i].resize(dim);
    
	random_device rd;
    mt19937 gen(rd());
    
    normal_distribution<double> distributionV(0.0,1.0);
    uniform_real_distribution<> distributionT(0.0, (double) this->w);
    
    double number;

    for (i = 0 ; i < size; i++) {
        for (j = 0; j < dim; j++) {

/*--------------------------------v initialization--------------------------------*/

            number = distributionV(gen);
            this->v[i][j] = number;


        }

        /*--------------------------------t initialization--------------------------------*/

        number = distributionT(gen);
        this->t[i] = number;

    }
	
}


int Projection::hashLSH(PointVector *p, int h){
	
	double sum = 0;
    int i;
    
    for (i = 0; i < p->getDimension(); i++)
		sum += (double)p->getCoordinate(i) * this->v[h][i];	
		
	sum += t[h];
	
	return floor(sum /= (double)this->w);
	
}


Projection::~Projection(){
	
	this->t.clear();
	for (int i = 0; i < v.size(); i++)
		this->v[i].clear();
		
	this->v.clear();
	
}
