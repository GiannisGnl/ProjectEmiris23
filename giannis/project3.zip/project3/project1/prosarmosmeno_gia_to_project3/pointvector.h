#ifndef POINTVECTOR_H
#define POINTVECTOR_H

#include <string>
#include <vector>

using namespace std;


class PointVector{
  
  private:
  
    unsigned int id;
    vector<unsigned char> co;
    bool flag;
  
  public:
    
    PointVector(unsigned int, vector<unsigned char>);
    int getDimension();
    unsigned int getID();
    bool getFlag();
    vector<unsigned char> getCoordinates();
    unsigned char getCoordinate(int pos);
    void setFlagTrue();
    ~PointVector();
    
};


#endif
