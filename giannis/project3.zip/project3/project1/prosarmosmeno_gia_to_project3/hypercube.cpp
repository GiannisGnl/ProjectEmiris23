#include "hypercube.h"
#include <random>
#include <cmath>
#include <algorithm>
#include <cfloat>
#include <string>
#include <chrono>
#include <fstream>
#include "metricl2.h"

using namespace std;
using namespace std::chrono;


Hypercube::Hypercube(int d, int tres, int p, int window, int dim, int lines) : Projection(){
	
	this->m = tres;
    this->setK(d);
    this->setW(window);
    
    
    this->vertices = (int) pow(2.0, (double)d);
    this->hashtables.resize(this->vertices);
    
    this->setVT (this->vertices, dim);
    
    this->probes = p;
    
    this->f = new int[this->vertices];
    
    random_device rd;
    mt19937 gen(rd());
	uniform_int_distribution<> distributionF(0, 1);
    
    int i;
    
    for (i = 0; i < this->vertices; i++){
		this->f[i] = distributionF(gen);
	}
	
}


void Hypercube::insert(PointVector* p){

	int pos = this->hashPosition(p);
	this->hashtables[pos].push_back(p);
	

}


void Hypercube::insert(vector<PointVector*> vec) {

    for (int i = 0; i < vec.size(); i++)
        this->insert(vec[i]);

}


int Hypercube::hashPosition(PointVector* p) {

    long long int pos = 0;

    int i;
    
    int bucket = 0;
    

    for (i = 0; i < this->getK(); i++){
		
		pos = this->hashLSH(p, i);
		pos = (pos % this->vertices + this->vertices) % this->vertices;
		
		if (f[(int)pos])
			bucket += (int) pow(2.0, (double)i);

	}
	
	return bucket;
    
}


vector<unsigned int> Hypercube::closestNeighbours(int n, PointVector* query){

    vector <double> distances;
    distances.resize(n);

    int i, j, bucketNum, pos;

    for (i = 0; i < n; i++) {

        distances[i] = DBL_MAX;

    }

    vector<unsigned int> nID;
    nID.resize(n);

    double currentDis;
    double tempD;
    unsigned int tempS;
    
    bucketNum = hashPosition(query);

    for (i = 0; i < this->vertices; i++){
		
		if (hammingDistance(bucketNum, i) > this->probes)
			continue;

        for (j = 0; j < this->m; j++){
			
			if (this->hashtables[i].size() == j)
				break;
			

            if (find(nID.begin(), nID.end(), this->hashtables[i][j]->getID()) != nID.end())
                continue;
			
            pos = n;
            currentDis = distanceL2(query, this->hashtables[i][j]);

            while (currentDis < distances[pos-1]){

 
                pos--;

                if (pos == n-1){

                    distances[pos] = currentDis;
                    nID[pos] = this->hashtables[i][j]->getID();

                }

                else{

                    tempD = distances[pos];
                    distances[pos+1] = tempD;
                    distances[pos] = currentDis;
                    tempS = nID[pos];
                    nID[pos+1] = tempS;
                    nID[pos] = this->hashtables[i][j]->getID();

                }


            }

        }
        
    }

    return nID;

}


void Hypercube::writeToFile(string fileName, vector<PointVector*> input, vector<PointVector*> queries, int n, double radius){
	
	double mDurApp = 0.0, mDurTrue = 0.0, af = 0.0, disLSH, disTrue, durApp, durTrue;
	
	string output = "";
	vector <unsigned int> nID, nIDt, rID;
	
	//start countdown
	auto start = high_resolution_clock::now();

	
	for (int i = 0; i < queries.size(); i++){
		
		//start countdown
		auto start = high_resolution_clock::now();
		
		nID = this->closestNeighbours(n, queries[i]);
	
		//stop countdown
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<microseconds>(stop - start);
		
		durApp = (double)duration.count();
		mDurApp += durApp;
	
		//start countdown
		start = high_resolution_clock::now();
		
		nIDt = this->trueClosestNeighbours(n, input, queries[i]);
		
		stop = high_resolution_clock::now();
		duration = duration_cast<microseconds>(stop - start);
		
		durTrue = (double)duration.count();
		mDurTrue += durTrue;
		//stop countdown
	
		output += "Query: ";
		output += to_string(i+1);
		output += "\n";
		
		for (int j = 0; j < n; j++){
			
			output += "Nearest neighbor-";
			output += to_string(j+1);
			output += ": ";
			output += to_string(nID[j]);
			output += "\n";
			
			output += "distanceHypercube: ";
			disLSH = distanceL2(queries[i], input[nID[j]-1]);
			output += to_string(disLSH);
			output += "\n";
			
			output += "distanceTrue: ";
			disTrue = distanceL2(queries[i], input[nIDt[j]-1]);
			output += to_string(disTrue);
			output += "\n";
			
			if (j == 0)
				af += disLSH / disTrue;
			
		}
		
		output += "tHypercube: ";
		output += to_string(durApp);
		output += "\n";

		output += "tTrue: ";
		output += to_string(durTrue);
		output += "\n";
		
		output += "R-near neighbors: ";
		
		vector<PointVector*> rID = this->rangeNeighbours(queries[i], radius);

		for (int j = 0; j < rID.size(); j++){

			output += to_string(rID[j]->getID());
			output += "\n";
		
		}
		
		//output += "\n";
		
		nID.clear();
		nIDt.clear();
		rID.clear();
	
	}
	
	nID.shrink_to_fit();
	nIDt.shrink_to_fit();
	rID.shrink_to_fit();
	output += "\n";
		
	output += "tAverageApproximate: ";
	output += to_string(mDurApp / (double) queries.size());
	output += "\n";
	
	output += "tAverageTrue: ";
	output += to_string(mDurTrue / (double) queries.size());
	output += "\n";
	
	output += "Mean AF: ";
	output += to_string(af / (double) queries.size());
	output += "\n";
		
	ofstream write(fileName);	
		
	write << output;
	
	write.close();
		
	
}


int Hypercube::hammingDistance(int n1, int n2){

    int x = n1 ^ n2;
    int setBits = 0;
 
    while (x > 0) {
        setBits += x & 1;
        x >>= 1;
    }
 
    return setBits;

}


Hypercube::~Hypercube(){
	
	
	int i, j;
	for (i = 0; i < hashtables.size(); i++){
		
		for (j = 0; j < hashtables[i].size(); j++){
		//	delete this->hashtables[i][j];
		}
			
		this->hashtables[i].clear();
		this->hashtables[i].shrink_to_fit();
		
		
	}
	
	delete(this->f);
	
	this->hashtables.clear();
	this->hashtables.shrink_to_fit();
	
}


vector<PointVector*> Hypercube::rangeNeighbours(PointVector* query, double range){
	
	
	
    vector<PointVector*> vec;
    vector<vector<int>> vert;
    
    
	vert.resize(this->probes);
	
	int i, j, x, bucketNum;
	
    bucketNum = this->hashPosition(query);
   

    for (i = 0; i < this->vertices; i++) {

		if (hammingDistance(bucketNum, i) > this->probes -1)
			continue;

        vert[hammingDistance(bucketNum, i)].push_back(i);

    }


    for (i = 0; i < vert.size(); i++) {

		for (j = 0; j < vert[i].size(); j++) {

			for (x = 0; x < this->m; x++) {

				if (this->hashtables[vert[i][j]].size() == x)
                    break;
                    
                if (query->getID() == this->hashtables[vert[i][j]][x]->getID())
						continue;
						
				if (this->hashtables[vert[i][j]][x]->getFlag())
					continue;

				if (distanceL2(query, this->hashtables[vert[i][j]][x]) < range){
					
					
				
					vec.push_back(this->hashtables[vert[i][j]][x]);
				
				}

             }

		}

	}

	vert.clear();
	
	
	return vec;


}


vector<unsigned int> Hypercube::trueClosestNeighbours(int n, vector<PointVector*> input, PointVector* query){
	
	vector <double> distancesT;
    distancesT.resize(n);

    int i, j, pos;

    for (i = 0; i < n; i++) {

        distancesT[i] = DBL_MAX;

    }

    vector<unsigned int> nIDt;
    nIDt.resize(n);

    double currentDis;
    double tempD;
    unsigned int tempS;
	
	for (i = 0; i < input.size(); i++) {

		pos = n;

		currentDis = distanceL2(query, input[i]);
		
        while (currentDis < distancesT[pos - 1]) {

            pos--;

            if (pos == n - 1) {

                distancesT[pos] = currentDis;
                nIDt[pos] = i+1;

            }

            else {

                tempD = distancesT[pos];
                distancesT[pos + 1] = tempD;
                distancesT[pos] = currentDis;
                tempS = nIDt[pos];
                nIDt[pos + 1] = tempS;
                nIDt[pos] = i+1;

            }
            
            if (pos == 0)
				break;

        }
	
	}
	
	return nIDt;
	
}


void Hypercube::writeToFile(string fileName, vector<PointVector*> queries, vector<PointVector*> startingInput, vector<PointVector*> startingQueries, int n, double radius){
	
	
	double mDurApp = 0.0, mDurTrue = 0.0, af = 0.0, disLSH, disTrue, durApp, durTrue;
	
	string output = "";
	vector <unsigned int> nID, nIDt, rID;
	
	//start countdown
	auto start = high_resolution_clock::now();

	
	for (int i = 0; i < queries.size(); i++){
		
		//start countdown
		auto start = high_resolution_clock::now();
		
		nID = this->closestNeighbours(n, queries[i]);
	
		//stop countdown
		auto stop = high_resolution_clock::now();
		auto duration = duration_cast<microseconds>(stop - start);
		
		durApp = (double)duration.count();
		mDurApp += durApp;
	
		//start countdown
		start = high_resolution_clock::now();
		
		nIDt = this->trueClosestNeighbours(n, startingInput, startingQueries[i]);
		
		stop = high_resolution_clock::now();
		duration = duration_cast<microseconds>(stop - start);
		
		durTrue = (double)duration.count();
		mDurTrue += durTrue;
		//stop countdown
	
		output += "Query: ";
		output += to_string(i+1);
		output += "\n";
		
		for (int j = 0; j < n; j++){
			
			output += "Nearest neighbor-";
			output += to_string(j+1);
			output += ": ";
			output += to_string(nID[j]);
			output += "\n";
			
			output += "distanceHypercube: ";
			disLSH = distanceL2(startingQueries[i], startingInput[nID[j]-1]);
			output += to_string(disLSH);
			output += "\n";
			
			output += "distanceTrue: ";
			disTrue = distanceL2(startingQueries[i], startingInput[nIDt[j]-1]);
			output += to_string(disTrue);
			output += "\n";
			
			if (j == 0)
				af += disLSH / disTrue;
			
		}
		
		output += "tHypercube: ";
		output += to_string(durApp);
		output += "\n";

		output += "tTrue: ";
		output += to_string(durTrue);
		output += "\n";
		
		output += "R-near neighbors: ";
		output += "\n";
		
		vector<PointVector*> rID = this->rangeNeighbours(queries[i], radius);

		for (int j = 0; j < rID.size(); j++){

			output += to_string(rID[j]->getID());
			output += "\n";
		
		}
		
		//output += "\n";
		
		nID.clear();
		nIDt.clear();
		rID.clear();
	
	}
	
	nID.shrink_to_fit();
	nIDt.shrink_to_fit();
	rID.shrink_to_fit();
	output += "\n";
		
	output += "tAverageApproximate: ";
	output += to_string(mDurApp / (double) queries.size());
	output += "\n";
	
	output += "tAverageTrue: ";
	output += to_string(mDurTrue / (double) queries.size());
	output += "\n";
	
	output += "Mean AF: ";
	output += to_string(af / (double) queries.size());
	output += "\n";
		
	ofstream write(fileName);	
		
	write << output;
	
	write.close();
	
}

