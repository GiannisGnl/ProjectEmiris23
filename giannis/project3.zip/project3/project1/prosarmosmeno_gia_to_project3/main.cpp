#include <iostream>
#include <vector>
#include <string>
#include <chrono>
#include <cmath>
#include <fstream>
#include "parse.h"
#include "pointvector.h"
#include "lsh.h"
#include "metricl2.h"
#include "hypercube.h"
#include "command.h"
#include "cluster.h"


using namespace std;
using namespace std::chrono;


int main(int argc, char** argv){
	
	const int dim = 15;
	const int dimStartingSpace = 784;
	const int queriesQuantity = 10;
	const int maxIterationsClassic = 5;
	const int maxIterationsRangeSearch = 8;
	const int window = 4;
	int maxIterationsAlgo;
	Cluster* clust;

    vector<PointVector*> toInsert, queries, startingSpaceInput, startingSpaceQueries;
    unsigned int imagesCounter;
    
	vector<string> commandStrings;
	string st = "";
	int i;
	
	for (i = 0; i < argc; i++){
		
		st += (string(argv[i]));
		st += " ";
	
	}
    
    Command* com;

    do{
		
		commandStrings = parseCommand(st);

		com = new Command(commandStrings);
		
		commandStrings.clear();
		

        if (com->getValid() == 1 || com->getValid() == 2){
			
				cout << endl;

				cout << "Reading input..." << endl;
	
				toInsert = parse(com->getInputFile(), &imagesCounter, dim);
				startingSpaceInput = parse(com->getStartingSpaceInputFile(), &imagesCounter, dimStartingSpace);
	
				cout << "Reading input finished!" << endl << endl;
				
				cout << "Reading queries..." << endl;
	
				queries = parse(com->getConfigurationFile(), &imagesCounter, dim, false, queriesQuantity);
				startingSpaceQueries = parse(com->getStartingSpaceQueryFile(), &imagesCounter, dimStartingSpace, false, queriesQuantity);
	
				cout << "Reading queries finished!" << endl << endl;

				if (com->getValid() == 1){
                
					cout << endl << "Creating LSH object..." << endl;
					//LSH *lshObj = new LSH(com->getLOrM(), com->getK(), window, dim, imagesCounter);
					LSH *lshObj = new LSH(com->getLOrM(), com->getK(), window, dimStartingSpace, imagesCounter);
					cout << "LSH object created!" << endl;
				
					cout << "Inserting Points into LSH structure..." << endl;
					lshObj->insert(toInsert);
					//lshObj->insert(startingSpaceInput);
					cout << "Points inserted into LSH structure!" << endl;
				
					cout << "Writing output into File..." << endl;
					//lshObj->writeToFile(com->getOutputFile(), queries, com->getN(), com->getRadius());
					//lshObj->writeToFile(com->getOutputFile(), toInsert, queries, com->getN(), com->getRadius());
					lshObj->writeToFile(com->getOutputFile(), queries, startingSpaceInput, startingSpaceQueries, com->getN(), com->getRadius());
					cout << "Output written into file!" << endl;
				
					cout << "Deleting LSH structure..." << endl;
					//delete lshObj;
					lshObj = NULL;
					cout << "LSH structure deleted!" << endl << endl;

				}

				else{

					cout << "Creating Hypercube object..." << endl;
					Hypercube *hcObj = new Hypercube(com->getK(), com->getLOrM(), com->getProbes(), window, dim, imagesCounter);
					cout << "Hypercube object created!" << endl;
				
					cout << "Inserting Points into Hypercube structure..." << endl;
					hcObj->insert(toInsert);
					cout << "Points inserted into Hypercube structure!" << endl;
				
					cout << "Writing output into File..." << endl;
					hcObj->writeToFile(com->getOutputFile(), queries, startingSpaceInput, startingSpaceQueries, com->getN(), com->getRadius());
					//writeToFile(com->getOutputFile(), queries, com->getN(), com->getRadius());
					cout << "Output written into file!" << endl;
				
					cout << "Deleting Hypercube structure..." << endl;
					delete hcObj;
					hcObj = NULL;
					cout << "Hypercube structure deleted!" << endl << endl;

				}
				
				for (int ind = 0; ind < toInsert.size(); ind++){
					
					delete toInsert[ind];
					delete startingSpaceInput[ind];
					
				}
				
				toInsert.clear();
				toInsert.shrink_to_fit();
				startingSpaceInput.clear();
				startingSpaceInput.shrink_to_fit();

        }

        else if (com->getValid() == 3){

            cout << "Reading input..." << endl;
	
			toInsert = parse(com->getInputFile(), &imagesCounter, dim);
	
			cout << "Reading input finished!" << endl << endl;
			
			cout << "Reading configuration..." << endl;
	
			ifstream conFile;
			string curLine;
			vector <string> fileStrings, temp;
			fileStrings.clear();
			int kClusters, lLSH = 3, kLSH = 4, mHC = 10, kHC = 3, pHC = 2;
			bool fileCorrect = true;
	
			conFile.open(com->getConfigurationFile());
	
			while (getline(conFile, curLine)) {

				temp = parseCommand(curLine);
		
				fileStrings.push_back(temp[0]);
				fileStrings.push_back(temp[1]);
		
				temp.clear();
		
		
			}
    
			conFile.close();
    
			string parValue;
    
    
			parValue = parameterValue(fileStrings, "number_of_clusters:");
    
			if (parValue == "")
				fileCorrect = false;
	
			else
				kClusters = stoi(parValue);

			parValue = parameterValue(fileStrings, "number_of_vector_hash_tables:");
	
			if (parValue != "")
				lLSH = stoi(parValue);
		
			parValue = parameterValue(fileStrings, "number_of_vector_hash_functions:");
	
			if (parValue != "")
				kLSH = stoi(parValue);

			parValue = parameterValue(fileStrings, "max_number_M_hypercube:");
	
			if (parValue != "")
				mHC = stoi(parValue);
		
			parValue = parameterValue(fileStrings, "number_of_hypercube_dimensions:");
	
			if (parValue != "")
				kHC = stoi(parValue);		
	
			parValue = parameterValue(fileStrings, "number_of_probes:");
	
			if (parValue != "")
				pHC = stoi(parValue);
	

			
			if (com->getMethod() == "Classic")
				maxIterationsAlgo = maxIterationsClassic;
			
			else
				maxIterationsAlgo = maxIterationsRangeSearch;
	
			cout << "Reading configuration finished!" << endl << endl;
			
			if (fileCorrect){
			
				cout << "Creating clusters..." << endl;
			
				auto start = high_resolution_clock::now();
			
				clust = new Cluster (kClusters, toInsert, dim, maxIterationsAlgo, lLSH, kLSH, mHC, kHC, pHC, com->getMethod());
			
				auto stop = high_resolution_clock::now();

				auto duration = duration_cast<microseconds>(stop - start);
			
				cout << "Writing clusters to file..." << endl;
			
				clust->writeToFile(com->getOutputFile(), com->getComplete(), to_string((double)duration.count() / 1000000.0));
			
				delete clust;
				clust = NULL;
				
			}
			
			else
				cout << "Number of clusters missing in configuration file" << endl;

        }

        else{
			
			if (st != "exit"){
				
				cout << "False command, please try again." << endl;
				cout << "The possible commands are the following: " << endl;
				cout << "Command 1" << endl;
				cout << "lsh -i <compressed input file> -q <compressed query file> -si <input file> -sq <query file> -k <int> -L <int> -o <output file> -N <number of nearest> -R <radius>" << endl;
				cout << "Obligatory parameters: compressed input file, compressed query file, input file, output file and query file" << endl;
				cout << "Default values for optional parameters: k = 4,  L = 5,  N = 1,  R = 10000" << endl << endl;
				cout << "Command 2" << endl;
				cout << "cube -i <compressed input file> -q <compressed query file> -si <input file> -sq <query file> -k <int> -M <int> -p <probes> -o <output file> -N <number of nearest> -R <radius>" << endl;
				cout << "Obligatory parameters: compressed input file, compressed query file, input file, output file and query file" << endl;
				cout << "Default values for optional parameters: k = 14,  M = 10,  probes = 2,  N = 1,  R = 10000" << endl << endl;
				cout << "Command 3" << endl;
				cout << "cluster -i <input file> -c <configuration file> -o <output file> -complete <optional> -m <method: Classic OR LSH OR Hypercube>" << endl << endl;
				cout << "Command 4 (if you want to terminate the program)" << endl;
				cout << "exit" << endl << endl;
				
			}

        }
		
		if (st == "exit"){
			
			cout << "Exiting the programm..." << endl << endl;
			break;
			
		}

		if (com->getValid())
			cout << "Command was executed succesfully!" << endl << endl;
			
		delete com;
		com = NULL;
		
		cout << "Please enter a command: " << endl;
		
		do{
			getline(cin, st);
			cout << endl;
		} while (st == "");

    } while(1);

	
    return 0;
    
}
