#include "command.h"
#include "parse.h"

using namespace std;


Command::Command(vector<string> inp){
	
	int i;
	
	if (inp[0] != "lsh" && inp[0] != "./lsh" && inp[0] != "cube" && inp[0] != "./cube" && inp[0] != "cluster" && inp[0] != "./cluster")
		this->valid = 0;
	
	else{
	
		string value;
		this->valid = 1;
		
		value = parameterValue(inp, "-i");
		if (value == "") 
			this->valid = 0;
		
		else
			this->inputFile = this->fixPath(value);
			
		value = parameterValue(inp, "-o");
		if (value == "") 
			this->valid = 0;
			
		else
			this->outputFile = this->fixPath(value);
			
		
		if (this->valid > 0 && this->valid < 4){
			
			if (inp[0] == "cluster" || inp[0] == "./cluster"){
				
				this->valid = 3;
				
				this->configurationFile = parameterValue(inp, "-c");
				
				if (this->configurationFile == "")
					this->valid = 0;
					
				else
					this->configurationFile = this->fixPath(this->configurationFile);
					
				this->method = parameterValue(inp, "-m");
					
				if (this->method != "Classic" && this->method != "LSH" && this->method != "Hypercube")
					this->valid = 0;
					
				else
					this->complete = found(inp, "-complete");
	
			}
			
			else{
				
				value = parameterValue(inp, "-q");
				if (value != "")
					this->configurationFile = value;
					
				else
					this->valid = 0;
					
				value = parameterValue(inp, "-si");
				if (value == "") 
					this->valid = 0;
		
				else
					this->startingSpaceInputFile = this->fixPath(value);
					
				value = parameterValue(inp, "-sq");
				if (value != "")
					this->startingSpaceQueryFile = this->fixPath(value);
					
				else
					this->valid = 0;
					
				if (this->valid){
				
	
					if (inp[0] == "lsh" || inp[0] == "./lsh"){
			
						this->k = 4;
						this->lOrM = 5;
						this->n = 1;
						this->radius = 10000.00;
				
				
						value = parameterValue(inp, "-k");

						if (value != "")
							this->k = stoi(value);
					

					
						value = parameterValue(inp, "-L");
						if (value != "")
							this->lOrM = stoi(value);
					
				
						value = parameterValue(inp, "-N");
						if (value != "")
							this->n = stoi(value);
						
						value = parameterValue(inp, "-R");
						if (value != "")
							this->radius = stod(value);
		
					}
		
					else{
				
						this->valid = 2;
						this->k = 14;
						this->lOrM = 10;
						this->probes = 2;
						this->n = 1;
						this->radius = 10000.00;
				
						value = parameterValue(inp, "-k");
						if (value != "")
							this->k = stoi(value);
					
						value = parameterValue(inp, "-L");
						if (value != "")
							this->lOrM = stoi(value);
					
						value = parameterValue(inp, "-probes");
						if (value != "")
							this->probes = stoi(value);
					
						value = parameterValue(inp, "-N");
						if (value != "")
							this->n = stoi(value);
					
						value = parameterValue(inp, "-R");
						if (value != "")
							this->radius = stod(value);
			
					}
			
				}
			
			}
		
			
	
		}
	
	}
	
}


int Command::getValid(){
	
	return this->valid;

}
	
	
string Command::getInputFile(){

	return this->inputFile;

}


string Command::getStartingSpaceInputFile(){

	return this->startingSpaceInputFile;

}
	
	
string Command::getOutputFile(){

	return this->outputFile;

}
	
	
string Command::getConfigurationFile(){

	return this->configurationFile;

}


string Command::getStartingSpaceQueryFile(){

	return this->startingSpaceQueryFile;

}

	
int Command::getK(){

	return this->k;

}
	
	
int Command::getLOrM(){

	return this->lOrM;

}
	
	
int Command::getProbes(){

	return this->probes;

}


int Command::getN(){

	return this->n;

}

	
double Command::getRadius(){

	return this->radius;

}
	
	
string Command::getMethod(){

	return this->method;

}


bool Command::getComplete(){

	return this->complete;

}


string Command::fixPath(string input){
	
	if (input[0] == '/')
	    input.erase(0, 1);
	
	int i = 0;

    while (i < input.length()){
	   
	   
	    if (input[i] == '/' && input[i+1] != '/'){
			input.insert(i, "/");
		
			i += 2;
		
		
		}
		
		i++;
	   
    }
    
    return input;
	
}
