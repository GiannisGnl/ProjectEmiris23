#ifndef CLUSTER_H
#define CLUSTER_H

#include "pointvector.h"
#include "lsh.h"
#include "hypercube.h"


class Cluster{

private:

    int kClusters;
    vector<PointVector*> centroids;
    vector<vector<PointVector*>> clusters;
    int maxIterations;
    int dimensions;
    int lLSH;
    int kLSH;
    int mHC;
    int kHC;
    int pHC;
    string method;
    LSH* lshObj;
    Hypercube* hcObj;


public:

	Cluster(int, vector<PointVector*>, int, int, int, int, int, int, int, string);
	void assign(vector<PointVector*>, double);
	void assignClassic(vector<PointVector*>);
	void assignLSH(double);
	void assignHypercube(double);
	void update(bool);
	PointVector* getCentroid(int);
	int clusterSize(int);
	vector<double> silhouette();
	void writeToFile(string, bool, string);
	~Cluster();

};


#endif
