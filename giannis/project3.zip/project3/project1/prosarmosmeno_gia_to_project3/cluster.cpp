#include <random>
#include <cmath>
#include <cfloat>
#include <algorithm>
#include <fstream>
#include <chrono>
#include "cluster.h"
#include "metricl2.h"


Cluster::Cluster(int k, vector<PointVector*> points, int dim, int maxIt, int lL, int kL, int mH, int kH, int pH, string meth){
	
	this->kClusters = k;
	this->centroids.resize(k);
	this->clusters.resize(k);
	this->dimensions = dim;
	this->maxIterations = maxIt;
	this->lLSH = lL;
    this->kLSH = kL;
    this->mHC = mH;
    this->kHC = kH;
    this->pHC = pH;
    this->method = meth;
    
    this->lshObj = NULL;
    this->hcObj = NULL;
    
    const int window = 5;
	
	random_device rd;
    mt19937 gen(rd());
	
	uniform_int_distribution<> distributionK(0, points.size()-1);
	
	int centroidID = distributionK(gen);
	
	this->centroids[0] = points[centroidID];
	this->clusters[0].push_back(points[centroidID]);
	
	vector<double> p, minVec;
	vector<int> positions;
	double min, max, curDis, sum, randomP;
	int posCentroid, counterC;
	
	for (int i = 0; i < k-1; i++){
		
		
		
		p.clear();
		p.push_back(0.0);
		sum = 0.0;
		positions.clear();
		positions.push_back(-1);
		
		minVec.clear();
		max = 0.0;
		
		for (int j = 0; j < points.size(); j++){
			
			//check if point is a centroid, if yes, continue
			if (find(this->centroids.begin(), this->centroids.end(), points[j]) != this->centroids.end())
                continue;
                
            min = DBL_MAX;
			
			
			for (int x = 0; x < i; x++){
				
				curDis = pow(distanceL2(points[j], this->centroids[x]), 2.0);
				
				if (curDis < min)				
					min = curDis;
				
			}
			
			//sum += min/max;
			
			sum += min;
			minVec.push_back(sum);
			
			if (min > max)
				max = min;
					
			
			//p.push_back(sum);
			positions.push_back(j);
			
		}
		
		counterC = 0;
		
		for (int j = 0; j < points.size(); j++){
			
			//check if point is a centroid, if yes, continue
			if (find(this->centroids.begin(), this->centroids.end(), points[j]) != this->centroids.end())
                continue;
            
		
			p.push_back(minVec[counterC] / max);
			positions.push_back(j);
			
			counterC++;
		
		}
		
		
		uniform_real_distribution<double> distributionP(0.0, p[p.size()-1]);
		randomP = distributionP(gen);
		
		
		//binary search --> vale to antistoixo centroid
		posCentroid = binarySearchPosition(p, randomP);
		this->centroids[i+1] = points[positions[posCentroid]];
		this->clusters[i+1].push_back(points[positions[posCentroid]]);
		
	}
	
	double rangeC = 0, curDisC;
	
	if (this->method != "Classic"){
		
		rangeC = DBL_MAX;
		
		for (int i = 0; i < this->kClusters; i++){
			
			for (int j = i+1; j < this->kClusters; j++){
				
				curDisC = distanceL2(this->centroids[i], this->centroids[j]);
				
				if (curDisC < rangeC)
					rangeC = curDisC;
				
			} 
			
		}
		
	}
	
	if (this->method == "LSH"){
	
	
		//dimiourgise to LSH kai vale ta simeia
		this->lshObj = new LSH(this->lLSH, this->kLSH, window, this->dimensions, points.size());
		lshObj->insert(points);
	
	}
		
	if (this->method == "Hypercube"){
		
		
		//dimiourgise to Hypercube kai vale ta simeia
		this->hcObj = new Hypercube(this->mHC, this->kHC, this->pHC, window, this->dimensions, points.size());
		hcObj->insert(points);
	
	}
	
	rangeC /= 2.0;
	
	this->assign(points, rangeC);
	this-> update(true);
	
	
	for (int i = 1; i < maxIterations; i++){
		
		rangeC *= 2.0;
		this->assign(points, rangeC);
		this->update(false);
		
	}
	
	
	double minDisFlag, curDisFlag, minPos;
	int counterFalse;
	
	if (this->method != "Classic"){
	
		for (int i = 0; i < points.size(); i++){
		
			minDisFlag = DBL_MAX;
		
			if (!points[i]->getFlag()){
			
				counterFalse++;
			
				for (int j = 0; j < this->kClusters; j++){
				
					curDisFlag = distanceL2(points[i], this->centroids[j]); 
				
					if (curDisFlag < minDisFlag){
					
						minDisFlag = curDisFlag;
						minPos = j;
					
					}
				
				}
			
				this->clusters[minPos].push_back(points[i]);
				points[i]->setFlagTrue();
			
			}
		
		}
	
	}
	
}


void Cluster::assign(vector<PointVector*> points, double range){
	
	if (this->method == "Classic")
		this->assignClassic(points);
		
	else if (this->method == "LSH")
		this->assignLSH(range);
		
	else
		this->assignHypercube(range);
	
}


void Cluster::assignClassic(vector<PointVector*> points){
	
	double min, curDis;
	int nearestCluster;
	
	for (int i = 0; i < this->kClusters; i++){
		
		this->clusters[i].clear();
		this->clusters[i].push_back(this->centroids[i]);
		
	}
	
	for (int i = 0; i < points.size(); i++){
		
		if (find(this->centroids.begin(), this->centroids.end(), points[i]) != this->centroids.end())
                continue;
		
		min = distanceL2(points[i], this->centroids[0]);
		nearestCluster = 0;
		
		
		for (int j = 1; j < this->kClusters; j++){
			
			curDis = distanceL2(points[i], this->centroids[j]);
			
			if (curDis < min){
				
				min = curDis;
				nearestCluster = j;
				
			}
			
		}
		
		this->clusters[nearestCluster].push_back(points[i]);
		
	}
	
}


void Cluster::assignLSH(double range){
	
	vector<vector<PointVector*>> newPoints;
	newPoints.resize(this->kClusters);
	
	for (int i = 0; i < this->kClusters; i++)
		newPoints[i] = this->lshObj->rangeNeighbours(this->centroids[i], range);
	
	
	//solve conflicts
		
	for (int i = 0; i < this->kClusters; i++){
		
		for (int x = 0; x < newPoints[i].size(); x++){
		
			for (int j = i+1; j < this->kClusters; j++){
				
				for (int y = 0; y < newPoints[j].size(); y++){
					
					if (newPoints[i][x]->getID() == newPoints[j][y]->getID()){
						
						if (distanceL2(newPoints[i][x], centroids[i]) < distanceL2(newPoints[j][y], centroids[j]))
							newPoints[j].erase(newPoints[j].begin() + y);
							
						else
							newPoints[i].erase(newPoints[i].begin() + x);
						
					}
					
				}
							
			}
				
		}
		
	}
	
	//end solve conflicts - vectors finalized
	
	for (int i = 0; i < this->kClusters; i++){
		
		for (int j = 0; j < newPoints[i].size(); j++){
			
			this->clusters[i].push_back(newPoints[i][j]);
			newPoints[i][j]->setFlagTrue();
			
		}
		
	}
	
	
}


void Cluster::assignHypercube(double range){
	
	vector<vector<PointVector*>> newPoints;
	newPoints.resize(this->kClusters);
	
	for (int i = 0; i < this->kClusters; i++)
		newPoints[i] = this->hcObj->rangeNeighbours(this->centroids[i], range);
	
	
	//solve conflicts
		
	for (int i = 0; i < this->kClusters; i++){
		
		for (int x = 0; x < newPoints[i].size(); x++){
		
			for (int j = i+1; j < this->kClusters; j++){
				
				for (int y = 0; y < newPoints[j].size(); y++){
					
					if (newPoints[i][x]->getID() == newPoints[j][y]->getID()){
						
						if (distanceL2(newPoints[i][x], centroids[i]) < distanceL2(newPoints[j][y], centroids[j]))
							newPoints[j].erase(newPoints[j].begin() + y);
							
						else
							newPoints[i].erase(newPoints[i].begin() + x);
						
					}
					
				}
							
			}
				
		}
	}
	
	
	//end solve conflicts - vectors finalized
	
	for (int i = 0; i < this->kClusters; i++)
		newPoints[i] = this->hcObj->rangeNeighbours(this->centroids[i], range);
	
	
	for (int i = 0; i < this->kClusters; i++){
		
		for (int j = 0; j < newPoints[i].size(); j++){
			
			this->clusters[i].push_back(newPoints[i][j]);
			newPoints[i][j]->setFlagTrue();
			
		}
		
	}
	
	
}


int Cluster::clusterSize(int pos){
	
	return clusters[pos].size();
	
}


void Cluster::update(bool firstIteration){
	
	if (!firstIteration){
		
		for (int i = 0; i < this->kClusters; i++){
		
			this->clusters[i].erase(clusters[i].begin());
			delete this->centroids[i];
		
		}
		
	}
	
	PointVector* newCentroid;
	
	unsigned long long int	coordinate;
	vector<unsigned char> coordinates;
	
	for (int i = 0; i < this->kClusters; i++){
		
		coordinates.clear();
	
		for (int j = 0; j < this->dimensions; j++){
			
			coordinate = 0;
			
			for (int x = 0; x < clusters[i].size(); x++){
				
				coordinate += (unsigned long long int) this->clusters[i][x]->getCoordinate(j);
				
			}
			
			coordinate /= (unsigned long long int) this->clusters[i].size();
			
			coordinates.push_back((unsigned char) coordinate);
			
		}
		
		newCentroid = new PointVector(0, coordinates);
		
		this->centroids[i] = newCentroid;
		
	}
	
		
}


PointVector* Cluster::getCentroid(int pos){
	
	if (pos > this->centroids.size())
		return NULL;
		
	return this->centroids[pos];
	
}


vector<double> Cluster::silhouette(){
	
	vector<double> result;
	double a, b, s, aTotal, bTotal, sTotal, minDis, curDis, curSumA, curSumB, sumTotalA = 0, sumTotalB = 0;
	
	int nearestCentroid, counterA, counterB, totalCounterA = 0, totalCounterB = 0;
	
	for (int i = 0; i < this->kClusters; i++){
		
		minDis = DBL_MAX;
		curSumA = 0;
		curSumB = 0;
		counterA = 0;
		counterB = 0;
		
		for (int j = 0; j < this->kClusters; j++){
			
			if (i == j)
				continue;
				
			curDis = distanceL2(this->centroids[i], this->centroids[j]);
			
			if (curDis < minDis){
				
				minDis = curDis;
				nearestCentroid = j;
				
			}
			
		}
		
		for (int j = 0; j < this->clusters[i].size(); j++){
			
			for (int x = j+1; x < this->clusters[i].size(); x++){
			
				curDis = distanceL2(this->clusters[i][j], this->clusters[i][x]);
				curSumA += curDis;
				counterA++;
			
			}
			
			for (int x = 0; x < this->clusters[nearestCentroid].size(); x++){
				
				curDis = distanceL2(this->clusters[i][j], this->clusters[nearestCentroid][x]);
				curSumB += curDis;
				counterB++;
				
			}
			
		}
		
		a = curSumA / (double) counterA;
		b = curSumB / (double) counterB;
		
		totalCounterA += counterA;
		totalCounterB += counterB;
		
		sumTotalA += curSumA;
		sumTotalB += curSumB;
		
		if (a > b)
			s = (b - a) / a;
		
		else
			s = (b - a) / b;
			
		result.push_back(s);
		
	}
	
	aTotal = sumTotalA / (double) totalCounterA;
	bTotal = sumTotalB / (double) totalCounterB;
	
	if (aTotal > bTotal)
			sTotal = (bTotal - aTotal) / aTotal;
		
	else
		sTotal = (bTotal - aTotal) / bTotal;
			
	result.push_back(sTotal);
	
	
	return result;
	
}


void Cluster::writeToFile(string fileName, bool complete, string time){
	
	
	string output = "Algorithm: ";
	
	if (this->method == "Classic")
		output += "Lloyds";
		
	else if (this->method == "LSH")
		output += "Range Search LSH";
		
	else
		output += "Range Search Hypercube";
	
	output += "\n";
	
	for (int i = 0; i < this->kClusters; i++){
		
		output += "CLUSTER-";
		output += to_string(i+1);
		output += " {size: ";
		output += to_string(this->clusters[i].size());
		output += " centroid: [";
		
		for (int j = 0; j < this->dimensions-1; j++){
			
			output += to_string((int) this->centroids[i]->getCoordinate(j));
			output += ", ";
			
		}
		
		output += to_string((int) this->centroids[i]->getCoordinate(this->dimensions-1));
		output += "]}";
		output += "\n";
		
		
		
	}
	
	//clustering time in seconds
	output += "clustering_time: ";
    output += time;
    output += "\n";
	
	output += "Silhouette: [";
		
	vector<double> sil = this->silhouette();
		
	for (int i = 0; i < sil.size() - 1; i++){
		
		output += to_string(sil[i]);
		output += ", ";
		
	}
	
	output += to_string(sil[sil.size()-1]);
	output += "]";
	
	if (complete){
		
		output += "\n";
		
		for (int i = 0; i < this->kClusters; i++){
			
			output += "CLUSTER-";
			output += to_string(i+1);
			output += " {centroid, ";
			
			for (int j = 0; j < this->clusters[i].size() - 1; j++){
				
				output += to_string(this->clusters[i][j]->getID());
				output += ", ";
				
			}
			
			output += to_string(this->clusters[i][this->clusters[i].size()-1]->getID());
			output += "}";
			
			if (i < this->kClusters-1)
				output += "\n";
			
		}
		
	}
	
	
	ofstream write(fileName);
	
	write << output;
	
	write.close();
	
}


Cluster::~Cluster(){
	
	bool classicSearch = true;
	
	if (this->method == "LSH"){
		
		classicSearch = false;
		delete this->lshObj;
		lshObj = NULL;
		
	}
	
	if (this->method == "Hypercube"){
		
		classicSearch = false;
		delete this->hcObj;
		hcObj = NULL;
		
	}
	

	for (int i = 0; i < this->kClusters; i++){

		delete centroids[i];
		
		if (classicSearch){
		
			for (int j = 0; j < this->clusters[i].size(); j++)
				delete this->clusters[i][j];
		
		}
			
		clusters[i].clear();
		
	}	
	
	this->clusters.clear();
	this->centroids.clear();
	
	this->kClusters = 0;
	this->dimensions = 0;
	this->method = "";


}

